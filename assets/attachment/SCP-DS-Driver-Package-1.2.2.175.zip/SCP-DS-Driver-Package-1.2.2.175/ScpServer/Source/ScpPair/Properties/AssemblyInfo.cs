﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ScpPair")]
[assembly: AssemblyProduct("ScpPair")]

[assembly: Guid("359e2b03-d7dd-48a2-893f-4ece5bd91258")]
